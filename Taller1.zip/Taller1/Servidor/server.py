import socket

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
backup = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('127.0.0.1', 5001))
client2.connect(('127.0.0.1', 5002))
backup.connect(('127.0.0.1',5010))
server.bind(('0.0.0.0', 5000))
server.listen(1)
while True:
    conn, addr = server.accept()
    print('Connected by', addr, conn.getsockname()[1])
    while True:
        data = conn.recv(1024)
        datito = data.decode().split('\n')[-1]
        try:
            client.sendall(datito.encode())
        except:
            print("Mensaje fallido hacia pc1")
        try:
            client2.sendall(datito.encode())
        except:
            print("Mensaje fallido hacia pc2")
        try:
            backup.sendall((datito+"SERVERMAXIMOSUPREMO").encode())
        except:
            print("mensaje fallido hacia backup")
        print("Dato recibido:", datito)
        if datito == "exit":
            conn.close()
            break

client.close()
client2.close()
conn.close()
