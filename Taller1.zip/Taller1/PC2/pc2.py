
import socket
import threading

def write_to_file(conn, addr):
    while True:
        data = conn.recv(1024)
        print('Received:', data.decode())
        f = open("file.txt", "at")
        f.write(data.decode()+" ")
        f.close()

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(('0.0.0.0', 5002))
server.listen(1)
while True:
    conn, addr = server.accept()
    threading.Thread(target=write_to_file, args=(conn, addr), daemon=True).start()
    # print('Connected by', addr)
    # data = conn.recv(1024)
    # if data.decode() == "exit":
    #     print("Finalizando conexión")
        # break
    # print('Received:', data.decode())
    # f = open("file.txt", "at")
    # f.write(data.decode()+" ")
    # f.close()
conn.close()


