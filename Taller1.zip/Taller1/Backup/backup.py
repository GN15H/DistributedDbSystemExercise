import socket

def write_to_file(conn, addr):
    while True:
        try:
            data = conn.recv(1024)
            print('Received:', data.decode())
            f = open("file.txt", "at")
            f.write(data.decode()+" ")
            f.close()
        except ConnectionRefusedError:
            break

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('127.0.0.1', 5001))
client2.connect(('127.0.0.1', 5002))
server.bind(('0.0.0.0', 5010))
server.listen(1)
while True:
    conn, addr = server.accept()
    while True:
        #19
        try:
            data = conn.recv(1024)
        except ConnectionResetError:
            break
        datito = data.decode().split('\n')[-1]
        if datito[-19:]!="SERVERMAXIMOSUPREMO":
            try:
                client.sendall(datito.encode())
            except:
                print("mensaje fallido hacia pc1")
            try:
                client2.sendall(datito.encode())
            except:
                print("mensaje fallido hacia pc2")
            f = open("file.txt", "at")
            f.write(data.decode()+" ")
            f.close()
        else:
            f = open("file.txt", "at")
            f.write(data.decode()[:-19]+" ")
            f.close()
        print("porfavo manodime ke le meti", datito[-19:])
        print("porfavo manodime ke le meti", datito[-19:])
        print("Dato recibido:", datito)
        if datito == "exit":
            conn.close()
            break

client.close()
client2.close()
conn.close()


