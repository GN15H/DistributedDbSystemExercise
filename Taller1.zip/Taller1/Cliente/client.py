import socket

def connect_to_server():
    sck = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sck.connect(('127.0.0.1', 5000))
    except ConnectionRefusedError:
        try:
            sck.connect(('127.0.0.1',5010))
        except ConnectionRefusedError:
            print("Conexión no posible")
            quit()
    return sck
   

ip_addr = '127.0.0.1'
# client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client = connect_to_server()
while True:
    data = str(input())
    try:
        client.sendall(data.encode())
    except:
        client = connect_to_server()
        client.sendall(data.encode())
    if data == "exit":
        break
client.close()